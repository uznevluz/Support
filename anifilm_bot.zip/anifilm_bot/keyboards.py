from aiogram.utils.keyboard import InlineKeyboardBuilder

import config


def main_menu_kb():
    b = InlineKeyboardBuilder()
    b.button(text="💡 Taklif", callback_data="cat:taklif")
    b.button(text="❓ Murojaat", callback_data="cat:murojaat")
    b.button(text="📢 Reklama", callback_data="cat:reklama")
    b.button(text="📢 Rasmiy kanallarimiz", callback_data="channels")
    b.adjust(1)
    return b.as_markup()


def channels_kb():
    b = InlineKeyboardBuilder()
    for name, link in config.OFFICIAL_CHANNELS:
        b.button(text=name, url=link)
    b.button(text="⬅️ Ortga", callback_data="back_to_menu")
    b.adjust(1)
    return b.as_markup()


def mark_read_kb(message_id):
    b = InlineKeyboardBuilder()
    b.button(text="✅ Xabarni o'qildi deb belgilash", callback_data=f"read_ticket:{message_id}")
    b.adjust(1)
    return b.as_markup()


def claim_kb(ticket_id):
    b = InlineKeyboardBuilder()
    b.button(text="🙋 Men javob beraman", callback_data=f"claim:{ticket_id}")
    b.adjust(1)
    return b.as_markup()


def view_reply_kb(message_id):
    b = InlineKeyboardBuilder()
    b.button(text="📖 Javobni ko'rish", callback_data=f"read_reply:{message_id}")
    b.adjust(1)
    return b.as_markup()


def admin_main_kb():
    b = InlineKeyboardBuilder()
    b.button(text="📋 Barcha xabarlar", callback_data="adm_list:all")
    b.button(text="💡 Takliflar", callback_data="adm_list:taklif")
    b.button(text="❓ Murojaatlar", callback_data="adm_list:murojaat")
    b.button(text="📢 Reklamalar", callback_data="adm_list:reklama")
    b.button(text="🔵 O'qilmaganlar", callback_data="adm_list:unread")
    b.button(text="📊 Statistika", callback_data="adm_stats")
    b.button(text="📤 Eksport (CSV)", callback_data="adm_export")
    b.button(text="🚫 Bloklangan foydalanuvchilar", callback_data="adm_blocked")
    b.button(text="⚙️ Sozlamalar", callback_data="adm_settings")
    b.adjust(1)
    return b.as_markup()


def ticket_admin_kb(ticket):
    tid = ticket["id"]
    b = InlineKeyboardBuilder()
    b.button(text="👤 Foydalanuvchi tarixi", callback_data=f"adm_history:{ticket['user_id']}")
    if ticket["tag"] == "hal qilindi":
        b.button(text="⏳ Kutilmoqda deb belgilash", callback_data=f"adm_tag:{tid}:kutilmoqda")
    else:
        b.button(text="✅ Hal qilindi deb belgilash", callback_data=f"adm_tag:{tid}:hal qilindi")
    if ticket.get("pinned"):
        b.button(text="📌 Pindan olish", callback_data=f"adm_pin:{tid}:0")
    else:
        b.button(text="📌 Pin qilish", callback_data=f"adm_pin:{tid}:1")
    b.button(text="🚫 Foydalanuvchini bloklash", callback_data=f"adm_block:{ticket['user_id']}")
    b.button(text="🗑 O'chirish", callback_data=f"adm_delete:{tid}")
    b.adjust(1)
    return b.as_markup()


def settings_kb():
    b = InlineKeyboardBuilder()
    b.button(text="🕐 Ish vaqtini o'zgartirish", callback_data="set_hours")
    b.button(text="⬅️ Ortga", callback_data="adm_back")
    b.adjust(1)
    return b.as_markup()
