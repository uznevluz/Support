import time
import json
import csv
import io
import aiosqlite

import config

DB_PATH = config.DB_PATH


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            full_name TEXT,
            is_blocked INTEGER DEFAULT 0,
            first_seen INTEGER,
            last_message_at INTEGER,
            window_start INTEGER DEFAULT 0,
            window_count INTEGER DEFAULT 0,
            last_text TEXT,
            last_text_time INTEGER DEFAULT 0
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            category TEXT,
            status TEXT DEFAULT 'open',
            tag TEXT DEFAULT 'kutilmoqda',
            claimed_by INTEGER,
            pinned INTEGER DEFAULT 0,
            created_at INTEGER
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_id INTEGER,
            sender TEXT,
            admin_id INTEGER,
            content_type TEXT,
            text TEXT,
            file_id TEXT,
            admin_chat_message_id INTEGER,
            is_read INTEGER DEFAULT 0,
            created_at INTEGER
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS admin_forward (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message_id INTEGER,
            ticket_id INTEGER,
            admin_id INTEGER,
            chat_message_id INTEGER
        )""")
        await db.commit()

        # standart sozlamalar
        defaults = {
            "working_hours_enabled": "1" if config.DEFAULT_WORKING_HOURS_ENABLED else "0",
            "working_hours_start": config.DEFAULT_WORKING_HOURS_START,
            "working_hours_end": config.DEFAULT_WORKING_HOURS_END,
        }
        for k, v in defaults.items():
            await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))
        await db.commit()


# ---------------- USERS ----------------

async def get_or_create_user(user_id, username, full_name):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT user_id FROM users WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        if not row:
            await db.execute(
                "INSERT INTO users (user_id, username, full_name, first_seen) VALUES (?,?,?,?)",
                (user_id, username, full_name, int(time.time()))
            )
        else:
            await db.execute(
                "UPDATE users SET username=?, full_name=? WHERE user_id=?",
                (username, full_name, user_id)
            )
        await db.commit()


async def is_blocked(user_id):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT is_blocked FROM users WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        return bool(row and row[0])


async def set_blocked(user_id, blocked: bool):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET is_blocked=? WHERE user_id=?", (1 if blocked else 0, user_id))
        await db.commit()


async def check_flood(user_id):
    """True qaytarsa - xabar yuborish mumkin. False - limit tugagan."""
    now = int(time.time())
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT window_start, window_count FROM users WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        if not row:
            return True
        window_start, window_count = row
        if now - window_start > config.FLOOD_LIMIT_SECONDS:
            await db.execute("UPDATE users SET window_start=?, window_count=1 WHERE user_id=?", (now, user_id))
            await db.commit()
            return True
        if window_count >= config.FLOOD_LIMIT_MESSAGES:
            return False
        await db.execute("UPDATE users SET window_count=window_count+1 WHERE user_id=?", (user_id,))
        await db.commit()
        return True


async def check_duplicate(user_id, text):
    if not text:
        return False
    now = int(time.time())
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT last_text, last_text_time FROM users WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        is_dup = False
        if row and row[0] == text and (now - (row[1] or 0)) < config.DUPLICATE_WINDOW_SECONDS:
            is_dup = True
        await db.execute("UPDATE users SET last_text=?, last_text_time=?, last_message_at=? WHERE user_id=?",
                          (text, now, now, user_id))
        await db.commit()
        return is_dup


# ---------------- TICKETS ----------------

async def get_open_ticket(user_id):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM tickets WHERE user_id=? AND status!='resolved' ORDER BY id DESC LIMIT 1",
            (user_id,)
        )
        row = await cur.fetchone()
        return dict(row) if row else None


async def create_ticket(user_id, category):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "INSERT INTO tickets (user_id, category, status, tag, created_at) VALUES (?,?,?,?,?)",
            (user_id, category, "open", "kutilmoqda", int(time.time()))
        )
        await db.commit()
        return cur.lastrowid


async def get_ticket(ticket_id):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM tickets WHERE id=?", (ticket_id,))
        row = await cur.fetchone()
        return dict(row) if row else None


async def claim_ticket(ticket_id, admin_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE tickets SET claimed_by=? WHERE id=?", (admin_id, ticket_id))
        await db.commit()


async def set_tag(ticket_id, tag):
    status = "resolved" if tag == "hal qilindi" else "open"
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE tickets SET tag=?, status=? WHERE id=?", (tag, status, ticket_id))
        await db.commit()


async def pin_ticket(ticket_id, pinned: bool):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE tickets SET pinned=? WHERE id=?", (1 if pinned else 0, ticket_id))
        await db.commit()


async def delete_ticket(ticket_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM tickets WHERE id=?", (ticket_id,))
        await db.execute("DELETE FROM messages WHERE ticket_id=?", (ticket_id,))
        await db.commit()


async def list_tickets(category=None, unread_only=False, limit=15):
    query = """
        SELECT t.*, u.username, u.full_name,
        (SELECT COUNT(*) FROM messages m WHERE m.ticket_id=t.id AND m.sender='user' AND m.is_read=0) as unread
        FROM tickets t JOIN users u ON u.user_id = t.user_id
        WHERE 1=1
    """
    params = []
    if category:
        query += " AND t.category=?"
        params.append(category)
    query += " ORDER BY t.pinned DESC, t.id DESC LIMIT ?"
    params.append(limit)
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(query, params)
        rows = await cur.fetchall()
        result = [dict(r) for r in rows]
        if unread_only:
            result = [r for r in result if r["unread"] > 0]
        return result


async def search_tickets(query_text, limit=15):
    like = f"%{query_text}%"
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("""
            SELECT DISTINCT t.*, u.username, u.full_name
            FROM tickets t
            JOIN users u ON u.user_id = t.user_id
            LEFT JOIN messages m ON m.ticket_id = t.id
            WHERE u.username LIKE ? OR u.full_name LIKE ? OR m.text LIKE ?
            ORDER BY t.id DESC LIMIT ?
        """, (like, like, like, limit))
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def get_user_tickets(user_id):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM tickets WHERE user_id=? ORDER BY id DESC", (user_id,))
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


# ---------------- MESSAGES ----------------

async def add_message(ticket_id, sender, content_type, text=None, file_id=None,
                       admin_id=None, admin_chat_message_id=None):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""
            INSERT INTO messages (ticket_id, sender, admin_id, content_type, text, file_id,
                                   admin_chat_message_id, created_at)
            VALUES (?,?,?,?,?,?,?,?)
        """, (ticket_id, sender, admin_id, content_type, text, file_id,
              admin_chat_message_id, int(time.time())))
        await db.commit()
        return cur.lastrowid


async def get_message(message_id):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM messages WHERE id=?", (message_id,))
        row = await cur.fetchone()
        return dict(row) if row else None


async def get_message_by_admin_chat_msg_id(admin_chat_message_id):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM messages WHERE admin_chat_message_id=?", (admin_chat_message_id,))
        row = await cur.fetchone()
        return dict(row) if row else None


async def add_admin_forward(message_id, ticket_id, admin_id, chat_message_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO admin_forward (message_id, ticket_id, admin_id, chat_message_id) VALUES (?,?,?,?)",
            (message_id, ticket_id, admin_id, chat_message_id)
        )
        await db.commit()


async def get_ticket_by_admin_forward(admin_id, chat_message_id):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM admin_forward WHERE admin_id=? AND chat_message_id=?",
            (admin_id, chat_message_id)
        )
        row = await cur.fetchone()
        return dict(row) if row else None


async def mark_message_read(message_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE messages SET is_read=1 WHERE id=?", (message_id,))
        await db.commit()


async def get_ticket_history(ticket_id):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM messages WHERE ticket_id=? ORDER BY id ASC", (ticket_id,))
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


# ---------------- SETTINGS ----------------

async def get_setting(key, default=None):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT value FROM settings WHERE key=?", (key,))
        row = await cur.fetchone()
        return row[0] if row else default


async def set_setting(key, value):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT INTO settings (key, value) VALUES (?,?) "
                          "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
        await db.commit()


# ---------------- STATS / EXPORT ----------------

async def get_stats():
    async with aiosqlite.connect(DB_PATH) as db:
        stats = {}
        cur = await db.execute("SELECT COUNT(*) FROM users")
        stats["users"] = (await cur.fetchone())[0]
        cur = await db.execute("SELECT COUNT(*) FROM tickets")
        stats["tickets_total"] = (await cur.fetchone())[0]
        for cat in config.CATEGORIES:
            cur = await db.execute("SELECT COUNT(*) FROM tickets WHERE category=?", (cat,))
            stats[f"cat_{cat}"] = (await cur.fetchone())[0]
        cur = await db.execute("SELECT COUNT(*) FROM tickets WHERE tag='hal qilindi'")
        stats["resolved"] = (await cur.fetchone())[0]
        cur = await db.execute("SELECT COUNT(*) FROM tickets WHERE tag='kutilmoqda'")
        stats["pending"] = (await cur.fetchone())[0]
        return stats


async def export_csv():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("""
            SELECT t.id as ticket_id, u.user_id, u.username, u.full_name, t.category, t.tag,
                   t.created_at, m.sender, m.text, m.created_at as msg_time
            FROM tickets t
            JOIN users u ON u.user_id = t.user_id
            LEFT JOIN messages m ON m.ticket_id = t.id
            ORDER BY t.id ASC, m.id ASC
        """)
        rows = await cur.fetchall()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ticket_id", "user_id", "username", "full_name", "category", "tag",
                      "ticket_created_at", "sender", "text", "msg_time"])
    for r in rows:
        writer.writerow(list(r))
    return output.getvalue()
