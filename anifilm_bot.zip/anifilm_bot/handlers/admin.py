from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, BufferedInputFile

import config
import database as db
import keyboards as kb

router = Router()


def is_admin(user_id):
    return user_id in config.ADMIN_IDS


def ticket_summary_line(t):
    unread_mark = "🔵" if t.get("unread", 0) > 0 else "🟢"
    pin_mark = "📌 " if t.get("pinned") else ""
    tag_mark = "✅" if t.get("tag") == "hal qilindi" else "⏳"
    username = f"@{t['username']}" if t.get("username") else t.get("full_name", "?")
    return f"{pin_mark}{unread_mark} {tag_mark} #{t['id']} — {username} ({config.CATEGORIES.get(t['category'], t['category'])})"


@router.message(Command("admin"))
async def admin_panel(message: Message):
    if not is_admin(message.from_user.id):
        return
    await message.answer("🛠 <b>Admin panel</b>", reply_markup=kb.admin_main_kb())


@router.callback_query(F.data == "adm_back")
async def adm_back(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return await call.answer()
    await call.message.edit_text("🛠 <b>Admin panel</b>", reply_markup=kb.admin_main_kb())
    await call.answer()


@router.callback_query(F.data.startswith("adm_list:"))
async def adm_list(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return await call.answer()
    kind = call.data.split(":")[1]
    if kind == "all":
        tickets = await db.list_tickets()
    elif kind == "unread":
        tickets = await db.list_tickets(unread_only=True)
    else:
        tickets = await db.list_tickets(category=kind)

    if not tickets:
        await call.message.edit_text("Hozircha xabar yo'q.", reply_markup=kb.admin_main_kb())
        return await call.answer()

    text = "📋 <b>Xabarlar ro'yxati</b>\n\n" + "\n".join(ticket_summary_line(t) for t in tickets)
    text += "\n\nTicket'ni ochish uchun: /ticket ID"
    await call.message.edit_text(text, reply_markup=kb.admin_main_kb())
    await call.answer()


@router.message(Command("ticket"))
async def open_ticket(message: Message):
    if not is_admin(message.from_user.id):
        return
    parts = message.text.split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.answer("Foydalanish: /ticket 5")
        return
    ticket_id = int(parts[1])
    ticket = await db.get_ticket(ticket_id)
    if not ticket:
        await message.answer("Bunday ticket topilmadi.")
        return
    history = await db.get_ticket_history(ticket_id)
    lines = [f"🎫 <b>Ticket #{ticket_id}</b> | {config.CATEGORIES.get(ticket['category'], ticket['category'])} | {ticket['tag']}\n"]
    for m in history:
        sender = "👤 Foydalanuvchi" if m["sender"] == "user" else "🛠 Admin"
        content_label = m["text"] if m["text"] else f"[{m['content_type']}]"
        lines.append(f"{sender}: {content_label}")
    await message.answer("\n".join(lines), reply_markup=kb.ticket_admin_kb(ticket))


@router.callback_query(F.data.startswith("adm_history:"))
async def adm_history(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return await call.answer()
    user_id = int(call.data.split(":")[1])
    tickets = await db.get_user_tickets(user_id)
    if not tickets:
        await call.answer("Tarix topilmadi.", show_alert=True)
        return
    lines = [f"👤 Foydalanuvchi <code>{user_id}</code> tarixi:\n"]
    for t in tickets:
        lines.append(ticket_summary_line(t))
    await call.message.answer("\n".join(lines))
    await call.answer()


@router.callback_query(F.data.startswith("adm_tag:"))
async def adm_tag(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return await call.answer()
    _, ticket_id, tag = call.data.split(":", 2)
    await db.set_tag(int(ticket_id), tag)
    await call.answer(f"Status: {tag}")


@router.callback_query(F.data.startswith("adm_pin:"))
async def adm_pin(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return await call.answer()
    _, ticket_id, val = call.data.split(":")
    await db.pin_ticket(int(ticket_id), val == "1")
    await call.answer("Yangilandi")


@router.callback_query(F.data.startswith("adm_delete:"))
async def adm_delete(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return await call.answer()
    ticket_id = int(call.data.split(":")[1])
    await db.delete_ticket(ticket_id)
    await call.answer("O'chirildi")
    await call.message.answer(f"🗑 Ticket #{ticket_id} o'chirildi.")


@router.callback_query(F.data.startswith("adm_block:"))
async def adm_block(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return await call.answer()
    user_id = int(call.data.split(":")[1])
    await db.set_blocked(user_id, True)
    await call.answer("Bloklandi")
    await call.message.answer(f"🚫 Foydalanuvchi <code>{user_id}</code> bloklandi.")


@router.message(Command("unblock"))
async def unblock_cmd(message: Message):
    if not is_admin(message.from_user.id):
        return
    parts = message.text.split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.answer("Foydalanish: /unblock 123456789")
        return
    await db.set_blocked(int(parts[1]), False)
    await message.answer("✅ Blokdan chiqarildi.")


@router.callback_query(F.data == "adm_blocked")
async def adm_blocked_list(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return await call.answer()
    await call.message.answer(
        "🚫 Bloklangan foydalanuvchini blokdan chiqarish uchun:\n/unblock USER_ID"
    )
    await call.answer()


@router.callback_query(F.data.startswith("claim:"))
async def claim_ticket_cb(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return await call.answer()
    ticket_id = int(call.data.split(":")[1])
    await db.claim_ticket(ticket_id, call.from_user.id)
    await call.answer("Siz ushbu ticket'ga javob berasiz.")
    await call.message.answer(f"🙋 Siz Ticket #{ticket_id} ga javobgar sifatida belgilandingiz.")


@router.callback_query(F.data.startswith("read_ticket:"))
async def admin_mark_read(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return await call.answer()
    message_id = int(call.data.split(":")[1])
    if message_id == 0:
        await call.answer("Bu xabar eskirgan format.")
        return
    msg = await db.get_message(message_id)
    if not msg:
        await call.answer("Xabar topilmadi.")
        return
    await db.mark_message_read(message_id)
    ticket = await db.get_ticket(msg["ticket_id"])
    if ticket:
        try:
            await call.bot.send_message(ticket["user_id"], "✅ Xabaringiz o'qildi. Tez orada javob beramiz.")
        except Exception:
            pass
    await call.answer("Belgilandi ✅")


@router.callback_query(F.data == "adm_stats")
async def adm_stats(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return await call.answer()
    s = await db.get_stats()
    lines = [
        "📊 <b>Statistika</b>\n",
        f"👥 Foydalanuvchilar: {s['users']}",
        f"🎫 Jami murojaatlar: {s['tickets_total']}",
        f"💡 Takliflar: {s.get('cat_taklif', 0)}",
        f"❓ Murojaatlar: {s.get('cat_murojaat', 0)}",
        f"📢 Reklamalar: {s.get('cat_reklama', 0)}",
        f"✅ Hal qilingan: {s['resolved']}",
        f"⏳ Kutilayotgan: {s['pending']}",
    ]
    await call.message.edit_text("\n".join(lines), reply_markup=kb.admin_main_kb())
    await call.answer()


@router.callback_query(F.data == "adm_export")
async def adm_export(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return await call.answer()
    csv_data = await db.export_csv()
    file = BufferedInputFile(csv_data.encode("utf-8"), filename="anifilm_murojaatlar.csv")
    await call.message.answer_document(file, caption="📤 Barcha murojaatlar eksporti")
    await call.answer()


@router.callback_query(F.data == "adm_settings")
async def adm_settings(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return await call.answer()
    enabled = await db.get_setting("working_hours_enabled", "1")
    start = await db.get_setting("working_hours_start", config.DEFAULT_WORKING_HOURS_START)
    end = await db.get_setting("working_hours_end", config.DEFAULT_WORKING_HOURS_END)
    status_label = "yoqilgan" if enabled == "1" else "o'chirilgan"
    text = (
        f"⚙️ <b>Sozlamalar</b>\n\n"
        f"🕐 Ish vaqti: {status_label}\n"
        f"Boshlanishi: {start}\nTugashi: {end}\n\n"
        f"O'zgartirish uchun: /sethours 09:00 18:00\n"
        f"Ish vaqtini o'chirish: /hoursoff\nYoqish: /hourson"
    )
    await call.message.edit_text(text, reply_markup=kb.settings_kb())
    await call.answer()


@router.message(Command("sethours"))
async def set_hours_cmd(message: Message):
    if not is_admin(message.from_user.id):
        return
    parts = message.text.split()
    if len(parts) != 3:
        await message.answer("Foydalanish: /sethours 09:00 18:00")
        return
    await db.set_setting("working_hours_start", parts[1])
    await db.set_setting("working_hours_end", parts[2])
    await message.answer(f"✅ Ish vaqti: {parts[1]} - {parts[2]}")


@router.message(Command("hoursoff"))
async def hours_off(message: Message):
    if not is_admin(message.from_user.id):
        return
    await db.set_setting("working_hours_enabled", "0")
    await message.answer("✅ Ish vaqti tekshiruvi o'chirildi (bot doim javob kutilmoqda deydi).")


@router.message(Command("hourson"))
async def hours_on(message: Message):
    if not is_admin(message.from_user.id):
        return
    await db.set_setting("working_hours_enabled", "1")
    await message.answer("✅ Ish vaqti tekshiruvi yoqildi.")


@router.message(Command("search"))
async def search_cmd(message: Message):
    if not is_admin(message.from_user.id):
        return
    query_text = message.text.replace("/search", "", 1).strip()
    if not query_text:
        await message.answer("Foydalanish: /search so'z_yoki_ism")
        return
    results = await db.search_tickets(query_text)
    if not results:
        await message.answer("Hech narsa topilmadi.")
        return
    lines = ["🔍 <b>Qidiruv natijalari:</b>\n"] + [ticket_summary_line(t) for t in results]
    await message.answer("\n".join(lines))


@router.message(Command("backup"))
async def backup_cmd(message: Message):
    if not is_admin(message.from_user.id):
        return
    try:
        with open(config.DB_PATH, "rb") as f:
            file = BufferedInputFile(f.read(), filename="anifilm_bot_backup.db")
        await message.answer_document(file, caption="🔄 Ma'lumotlar bazasi zaxira nusxasi")
    except Exception as e:
        await message.answer(f"Xatolik: {e}")


# Admin reply orqali foydalanuvchiga javob yuborish
@router.message(F.reply_to_message)
async def handle_admin_reply(message: Message):
    if not is_admin(message.from_user.id):
        return

    forward = await db.get_ticket_by_admin_forward(message.from_user.id, message.reply_to_message.message_id)
    if not forward:
        return  # oddiy reply, ticketga aloqasi yo'q

    ticket_id = forward["ticket_id"]
    ticket = await db.get_ticket(ticket_id)
    if not ticket:
        await message.answer("Ticket topilmadi (o'chirilgan bo'lishi mumkin).")
        return

    if message.text:
        content_type, text_val, file_id = "text", message.text, None
    elif message.photo:
        content_type, text_val, file_id = "photo", message.caption, message.photo[-1].file_id
    elif message.video:
        content_type, text_val, file_id = "video", message.caption, message.video.file_id
    elif message.document:
        content_type, text_val, file_id = "document", message.caption, message.document.file_id
    else:
        content_type, text_val, file_id = "text", message.text or "", None

    reply_msg_id = await db.add_message(
        ticket_id, "admin", content_type, text_val, file_id, admin_id=message.from_user.id
    )

    reply_kb = kb.view_reply_kb(reply_msg_id)
    try:
        if content_type == "text":
            await message.bot.send_message(ticket["user_id"], text_val or "", reply_markup=reply_kb)
        elif content_type == "photo":
            await message.bot.send_photo(ticket["user_id"], file_id, caption=text_val or "", reply_markup=reply_kb)
        elif content_type == "video":
            await message.bot.send_video(ticket["user_id"], file_id, caption=text_val or "", reply_markup=reply_kb)
        elif content_type == "document":
            await message.bot.send_document(ticket["user_id"], file_id, caption=text_val or "", reply_markup=reply_kb)
        await message.answer("✅ Javobingiz foydalanuvchiga yuborildi.")
    except Exception as e:
        await message.answer(f"❌ Yuborib bo'lmadi: {e}")
