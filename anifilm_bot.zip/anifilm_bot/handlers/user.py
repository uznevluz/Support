import time
from aiogram import Router, F
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery

import config
import database as db
import keyboards as kb

router = Router()

WELCOME_TEXT = (
    "📢 <b>Taklif, Murojaat va Reklama</b>\n\n"
    "Assalomu alaykum!\n\n"
    "Anifilm.uz jamoasi sizning har bir fikr va taklifingizni qadrlaydi.\n\n"
    "💡 Takliflaringiz orqali platformamizni yanada rivojlantirishga yordam bera olasiz.\n"
    "❓ Savol yoki murojaatlaringiz bo'lsa, administrator bilan bog'laning.\n"
    "📢 Reklama, hamkorlik yoki biznes takliflari bo'yicha ham murojaat qilishingiz mumkin.\n\n"
    "📝 Quyidagi bo'limlardan birini tanlang."
)

CATEGORY_PROMPT = {
    "taklif": "💡 Taklifingizni yozib qoldiring (matn, rasm yoki video yuborishingiz mumkin).",
    "murojaat": "❓ Murojaatingizni yozib qoldiring (matn, rasm yoki video yuborishingiz mumkin).",
    "reklama": "📢 Reklama/hamkorlik taklifingizni yozib qoldiring (matn, rasm yoki video yuborishingiz mumkin).",
}

# foydalanuvchi hozir qaysi kategoriyani tanlaganini vaqtincha eslab turish (RAMda)
user_pending_category = {}


async def is_within_working_hours():
    enabled = await db.get_setting("working_hours_enabled", "1")
    if enabled != "1":
        return True
    start = await db.get_setting("working_hours_start", config.DEFAULT_WORKING_HOURS_START)
    end = await db.get_setting("working_hours_end", config.DEFAULT_WORKING_HOURS_END)
    now = time.strftime("%H:%M")
    return start <= now <= end


def match_faq(text):
    if not text:
        return None
    lowered = text.lower()
    for keyword, answer in config.FAQ_ANSWERS.items():
        if keyword in lowered:
            return answer
    return None


def contains_banned_words(text):
    if not text:
        return False
    lowered = text.lower()
    return any(w in lowered for w in config.BANNED_WORDS)


@router.message(CommandStart())
async def cmd_start(message: Message):
    await db.get_or_create_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    if await db.is_blocked(message.from_user.id):
        await message.answer("🚫 Siz botdan foydalanish huquqidan mahrum qilingansiz.")
        return
    await message.answer(WELCOME_TEXT, reply_markup=kb.main_menu_kb())


@router.callback_query(F.data == "back_to_menu")
async def back_to_menu(call: CallbackQuery):
    await call.message.edit_text(WELCOME_TEXT, reply_markup=kb.main_menu_kb())
    await call.answer()


@router.callback_query(F.data == "channels")
async def show_channels(call: CallbackQuery):
    text = "📢 <b>Rasmiy kanallarimiz:</b>\n\nQuyidagi tugmalar orqali kanallarimizga o'ting."
    await call.message.edit_text(text, reply_markup=kb.channels_kb())
    await call.answer()


@router.callback_query(F.data.startswith("cat:"))
async def choose_category(call: CallbackQuery):
    category = call.data.split(":")[1]
    user_pending_category[call.from_user.id] = category
    await call.message.answer(CATEGORY_PROMPT[category])
    await call.answer()


@router.message(F.text | F.photo | F.video | F.document)
async def handle_user_message(message: Message):
    user = message.from_user
    if user.id in config.ADMIN_IDS:
        return  # adminning oddiy xabarlari ticket oqimiga tushmasin
    await db.get_or_create_user(user.id, user.username, user.full_name)

    if await db.is_blocked(user.id):
        await message.answer("🚫 Siz botdan foydalanish huquqidan mahrum qilingansiz.")
        return

    if not await db.check_flood(user.id):
        await message.answer("⏳ Siz juda tez-tez xabar yuboryapsiz. Iltimos, biroz kuting.")
        return

    text = message.text or message.caption

    if contains_banned_words(text):
        await message.answer("⚠️ Xabaringizda taqiqlangan so'zlar aniqlandi. Iltimos, xabaringizni tahrirlab qayta yuboring.")
        return

    if text and await db.check_duplicate(user.id, text):
        await message.answer("📵 Siz shu xabarni allaqachon yubordingiz. Iltimos, kuting, tez orada javob beramiz.")
        return

    faq_answer = match_faq(text)

    category = user_pending_category.pop(user.id, None)
    ticket = await db.get_open_ticket(user.id)

    if category:
        ticket_id = await db.create_ticket(user.id, category)
        ticket = await db.get_ticket(ticket_id)
    elif ticket:
        ticket_id = ticket["id"]
    else:
        await message.answer("Iltimos, avval bo'lim tanlang:", reply_markup=kb.main_menu_kb())
        return

    if message.text:
        content_type, text_val, file_id = "text", message.text, None
    elif message.photo:
        content_type, text_val, file_id = "photo", message.caption, message.photo[-1].file_id
    elif message.video:
        content_type, text_val, file_id = "video", message.caption, message.video.file_id
    elif message.document:
        content_type, text_val, file_id = "document", message.caption, message.document.file_id
    else:
        content_type, text_val, file_id = "text", message.text or "", None

    msg_id = await db.add_message(ticket_id, "user", content_type, text_val, file_id)

    category_label = config.CATEGORIES.get(ticket["category"], ticket["category"])
    username = f"@{user.username}" if user.username else "username yo'q"
    header = (
        f"🆕 <b>Yangi xabar</b> | {category_label}\n"
        f"👤 {user.full_name} ({username})\n"
        f"🆔 <code>{user.id}</code>\n"
        f"🎫 Ticket #{ticket_id}\n"
        f"───────────────"
    )

    working = await is_within_working_hours()

    for admin_id in config.ADMIN_IDS:
        try:
            await message.bot.send_message(admin_id, header, reply_markup=kb.claim_kb(ticket_id))
            if content_type == "text":
                sent = await message.bot.send_message(admin_id, text_val or "")
            elif content_type == "photo":
                sent = await message.bot.send_photo(admin_id, file_id, caption=text_val or "")
            elif content_type == "video":
                sent = await message.bot.send_video(admin_id, file_id, caption=text_val or "")
            elif content_type == "document":
                sent = await message.bot.send_document(admin_id, file_id, caption=text_val or "")
            else:
                continue

            await message.bot.edit_message_reply_markup(
                chat_id=admin_id, message_id=sent.message_id, reply_markup=kb.mark_read_kb(msg_id)
            )
            await db.add_admin_forward(msg_id, ticket_id, admin_id, sent.message_id)
        except Exception:
            continue

    if faq_answer:
        await message.answer(faq_answer)
    else:
        confirm = "✅ Xabaringiz qabul qilindi, tez orada javob beramiz."
        if not working:
            confirm += "\n\n🕐 Hozir ish vaqtidan tashqari, shuning uchun javob berish biroz kechikishi mumkin."
        await message.answer(confirm)


@router.callback_query(F.data.startswith("read_reply:"))
async def user_read_reply(call: CallbackQuery):
    message_id = int(call.data.split(":")[1])
    msg = await db.get_message(message_id)
    if not msg:
        await call.answer("Xabar topilmadi.")
        return
    await db.mark_message_read(message_id)
    ticket = await db.get_ticket(msg["ticket_id"])
    admin_id = msg["admin_id"] or (ticket.get("claimed_by") if ticket else None)
    if admin_id:
        try:
            await call.bot.send_message(
                admin_id,
                f"✅ Foydalanuvchi javobingizni o'qidi. (Ticket #{ticket['id']})"
            )
        except Exception:
            pass
    await call.answer("Rahmat!")
