import asyncio
import logging

from aiohttp import web
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

import config
import database as db
from handlers import admin as admin_handlers
from handlers import user as user_handlers

logging.basicConfig(level=logging.INFO)


async def on_startup(bot: Bot):
    await db.init_db()
    logging.info("Baza tayyor, bot ishga tushmoqda...")


async def run_bot():
    if not config.BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN environment variable topilmadi! Render sozlamalarida qo'shing.")

    bot = Bot(token=config.BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()

    dp.include_router(admin_handlers.router)
    dp.include_router(user_handlers.router)

    dp.startup.register(on_startup)

    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


async def handle_ping(request):
    return web.Response(text="Anifilm bot ishlayapti ✅")


async def run_webserver():
    app = web.Application()
    app.router.add_get("/", handle_ping)
    app.router.add_get("/health", handle_ping)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", config.PORT)
    await site.start()
    logging.info(f"Web-server {config.PORT}-portda ishga tushdi (Render/UptimeRobot uchun).")


async def main():
    await asyncio.gather(run_webserver(), run_bot())


if __name__ == "__main__":
    asyncio.run(main())
