# Anifilm.uz — Aloqa Boti

Bu bot orqali foydalanuvchilar Taklif / Murojaat / Reklama yuboradi, admin(lar) javob beradi,
ikki tomonlama "o'qildi" tizimi ishlaydi, admin panelda xabarlarni boshqarish mumkin.

## 1. Botni Render'ga joylashtirish (bosqichma-bosqich)

1. https://render.com saytiga kiring, GitHub akkauntingiz bilan ro'yxatdan o'ting (bepul).
2. Bu papkadagi barcha fayllarni GitHub'da yangi repository (masalan `anifilm-bot`) ga yuklang.
3. Render'da **New +** → **Web Service** ni tanlang.
4. GitHub repository'ngizni ulang.
5. Sozlamalar:
   - **Environment**: Python 3
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python bot.py`
   - **Plan**: Free
6. **Environment Variables** bo'limida qo'shing:
   - `BOT_TOKEN` = sizning bot tokeningiz
   - `ADMIN_IDS` = `5383321037` (bir nechta admin bo'lsa: `5383321037,222222222`)
7. **Create Web Service** tugmasini bosing — Render avtomatik o'rnatib, ishga tushiradi.

Bir necha daqiqadan so'ng bot ishga tushadi. Telegram'da botingizga `/start` yozib tekshiring.

## 2. Botni doim uyg'oq ushlab turish (MUHIM)

Render bepul tarifida 15 daqiqa faoliyatsiz qolsa bot "uxlab qoladi". Buni oldini olish uchun:

1. https://uptimerobot.com saytiga kiring, bepul ro'yxatdan o'ting.
2. **Add New Monitor** → **HTTP(s)** turi.
3. **URL** qismiga Render bergan manzilni qo'ying (masalan `https://anifilm-aloqa-bot.onrender.com`).
4. **Monitoring Interval**: 5 daqiqa qilib qo'ying.
5. Saqlang.

Shundan keyin UptimeRobot har 5 daqiqada botga "salom" berib turadi, u uxlab qolmaydi.

## 3. Admin buyruqlari (Telegram'da adminga yoziladi)

- `/admin` — Admin panelni ochish (xabarlar, statistika, eksport va h.k.)
- `/ticket 5` — 5-raqamli murojaatni to'liq ko'rish
- `/search so'z` — xabarlar orasidan qidirish
- `/unblock 123456789` — foydalanuvchini blokdan chiqarish
- `/sethours 09:00 18:00` — ish vaqtini o'zgartirish
- `/hoursoff` / `/hourson` — ish vaqti tekshiruvini o'chirish/yoqish
- `/backup` — ma'lumotlar bazasi zaxira nusxasini olish

**Javob berish**: adminga kelgan xabarga oddiy "Reply" qilib javob yozsangiz, bot uni avtomatik
foydalanuvchiga yuboradi.

## 4. Sozlash kerak bo'lgan joylar

- `config.py` faylida:
  - `OFFICIAL_CHANNELS` — rasmiy kanallaringiz nomi va linki
  - `FAQ_ANSWERS` — botning o'zi avtomatik javob beradigan savol-javoblar
  - `BANNED_WORDS` — taqiqlangan so'zlar ro'yxati

## 5. Eslatma

- Bot foydalanuvchiga xabar "o'qildi"ligini bildirish uchun tugmalardan foydalanadi
  (Telegram API haqiqiy "o'qildi" belgisini bermaydi, shuning uchun bu eng ishonchli yechim).
- Ma'lumotlar SQLite faylida (`bot.db`) saqlanadi. Render bepul tarifida disk vaqti-vaqti bilan
  tozalanishi mumkin — muhim ma'lumotlarni `/backup` orqali vaqti-vaqti bilan yuklab oling.
